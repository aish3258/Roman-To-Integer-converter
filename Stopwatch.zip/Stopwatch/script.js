/* -------------------- TIMER LOGIC -------------------- */

let startTime = 0;
let elapsedTime = 0;
let timerInterval = null;
let isRunning = false;

const hoursEl = document.getElementById("hours");
const minutesEl = document.getElementById("minutes");
const secondsEl = document.getElementById("seconds");

const startStopBtn = document.getElementById("startStopBtn");
const resetBtn = document.getElementById("resetBtn");
const startStopLabel = startStopBtn.querySelector(".btn-label");
const content = document.querySelector(".content");

function updateDisplay() {
  let totalSecs = Math.floor(elapsedTime / 1000);
  let h = String(Math.floor(totalSecs / 3600)).padStart(2, "0");
  let m = String(Math.floor((totalSecs % 3600) / 60)).padStart(2, "0");
  let s = String(totalSecs % 60).padStart(2, "0");

  hoursEl.textContent = h;
  minutesEl.textContent = m;
  secondsEl.textContent = s;
}

function startTimer() {
  startTime = Date.now() - elapsedTime;
  timerInterval = setInterval(() => {
    elapsedTime = Date.now() - startTime;
    updateDisplay();
  }, 1000);
}

function stopTimer() {
  clearInterval(timerInterval);
}

startStopBtn.addEventListener("click", () => {
  if (!isRunning) {
    isRunning = true;
    startTimer();
    startStopLabel.textContent = "Stop";
    resetBtn.disabled = false;
    content.classList.add("running");
  } else {
    isRunning = false;
    stopTimer();
    startStopLabel.textContent = "Start";
    content.classList.remove("running"); 
  }
});

resetBtn.addEventListener("click", () => {
  isRunning = false;
  stopTimer();
  elapsedTime = 0;
  updateDisplay();
  startStopLabel.textContent = "Start";
  resetBtn.disabled = true;
});

/* -------------------- SNOW -------------------- */

const snowLayer = document.getElementById("snowLayer");

function createSnowflakes(count = 80) {
  snowLayer.innerHTML = "";
  const width = window.innerWidth;

  for (let i = 0; i < count; i++) {
    const flake = document.createElement("span");
    flake.classList.add("snowflake");
    flake.textContent = "*";

    flake.style.left = `${Math.random() * width}px`;
    flake.style.fontSize = `${Math.random() * 11 + 9}px`;
    flake.style.animationDuration = `${Math.random() * 5 + 8}s`;
    flake.style.animationDelay = `${Math.random() * 10}s`;

    snowLayer.appendChild(flake);
  }
}

createSnowflakes();
window.addEventListener("resize", createSnowflakes);

/* -------------------- CAT ANIMATION -------------------- */

const cat = document.querySelector(".cat-wrapper");
const eyes = document.querySelectorAll(".eye");

document.addEventListener("keydown", (e) => {
  if (e.code === "Space") {
    e.preventDefault(); // stop page from scrolling
    startStopBtn.click();
  }
  if (e.key === "r" || e.key === "R") {
    resetBtn.click();
  }
});


document.addEventListener("mousemove", (e) => {
  const x = (e.clientX / window.innerWidth - 0.5) * 20;
  const y = (e.clientY / window.innerHeight - 0.5) * 20;

  document.querySelector('.cat-wrapper').style.transform = `translate(${x}px, ${y}px)`;
  document.querySelector('.totoro-wrapper').style.transform = `translate(${-x}px, ${-y}px)`;
  document.querySelector('.castle-wrapper').style.transform = `translate(${x/2}px, ${-y/2}px)`;
});
